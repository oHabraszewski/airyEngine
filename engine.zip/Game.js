class Game{
    constructor(width = 300, height = 300, create = ()=>{}, update = ()=>{}, fps = 30, root = null){
        this.w = width;
        this.h = height;
        this.fps = fps
        this.layers = []
        this.create = create;
        this.update = update;
        if(root == null){
            this.root = document.body
        }else{
            this.root = root;
        }
        this.clock = setInterval(()=>{
            this.update()
            this.layers.forEach(layer => {
                layer.drawEntities()
                layer.collideEntities()
            });
        }, 1000/this.fps)
    }
    add(layer){
        this.canvas = document.createElement("canvas")
        this.canvas.setAttribute("width", this.w)
        this.canvas.setAttribute("height", this.h)
        this.root.appendChild(this.canvas)
        this.layers.push(layer)
        layer.initialize(this.layers.length-1, this.canvas, this.w, this.h, this.fps)
    }
}
export default Game;